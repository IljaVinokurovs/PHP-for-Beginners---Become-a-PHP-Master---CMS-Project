<?php
if(isset($_GET['e_id'])){ //code to be modified to look for the location in the database and convert it to longlat
?>
    <div class="col-md-4">
        <?php
        $location = $event_location;

        function get_lat_long($address){



            $address = str_replace(" ", "+", $address);

            $json = file_get_contents("https://maps.googleapis.com/maps/api/geocode/json?address=$address&key=AIzaSyAoPlieU4I-x1ZBfdgQ-sx8EB7hM_Pz9ps");
            $json = json_decode($json);


            $lat = $json->{'results'}[0]->{'geometry'}->{'location'}->{'lat'};
            $long = $json->{'results'}[0]->{'geometry'}->{'location'}->{'lng'};
            return $lat.','.$long;
        }

        $latlong    =   get_lat_long($location); // create a function with the name "get_lat_long" given as below
        $map        =   explode(',' ,$latlong);
        $mapLat     =   $map[0];
        $mapLong    =   $map[1];

        ?>     

        <style>
              #map {
            /*        width: 350px;*/
                height: 400px;
              }
        </style>
        <div id="map"></div>

        <script>
          function initMap() {

            var myLatLng = {lat: <?php echo $mapLat;?>, lng: <?php echo $mapLong;?>};

                var map = new google.maps.Map(document.getElementById('map'), {
                  zoom: 15,
                  center: myLatLng
                });

                var marker = new google.maps.Marker({
                  position: myLatLng,
                  map: map,
                  title: '<?php echo $event_title ;?>'
                });
          }
        </script>

        <script async defer
            src="https://maps.googleapis.com/maps/api/js?key=AIzaSyD7CU5Y2iOi19q1R8LhBcIIKJUXGyLIh6w	
        &callback=initMap">
            </script>
    </div>
<?php
}
?>