<?php include "db.php"; ?>
<?php session_start() ?>
<?php ob_start() ?>

<?php
unset($_SESSION['user_id']);
unset($_SESSION['username']);
unset($_SESSION['firstname']);
unset($_SESSION['lastname']);
unset($_SESSION['user_role']);
header("Location: ../index.php");
       
?>