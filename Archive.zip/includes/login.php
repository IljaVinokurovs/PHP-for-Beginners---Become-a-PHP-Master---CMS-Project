<?php include "db.php"; ?>
<?php session_start() ?>
<?php ob_start() ?>

<?php
if(isset($_POST['login'])){
    $username = $_POST['username'];
    $username = mysqli_real_escape_string($connection, $username);
    $user_password = $_POST['user_password'];
    $user_password = mysqli_real_escape_string($connection, $user_password);
    
    $query = "SELECT * FROM users WHERE username = '{$username}'";
    $select_user_query = mysqli_query($connection, $query);
    $user_r = mysqli_fetch_assoc($select_user_query);
    $db_user_role = $user_r['user_role'];
    $db_user_firstname = $user_r['user_firstname'];
    $db_user_lastname = $user_r['user_lastname'];
    $db_user_password = $user_r['user_password'];
    $db_username = $user_r['username'];
    $db_user_id = $user_r['user_id'];
   
    if(password_verify($user_password, $db_user_password)){// can be hash with the password and output will be the same
    
        if($db_user_role ==  'Subscriber'){
            $_SESSION['user_id'] = $db_user_id;
            $_SESSION['username'] = $db_username;
            $_SESSION['firstname'] = $db_user_firstname;
            $_SESSION['lastname'] = $db_user_lastname;
            $_SESSION['user_role'] = $db_user_role;
           // print_r($_SESSION);
            header("Location: ../index.php");
        }elseif($db_user_role == 'Admin'){
            $_SESSION['user_id'] = $db_user_id;
            $_SESSION['username'] = $db_username;
            $_SESSION['firstname'] = $db_user_firstname;
            $_SESSION['lastname'] = $db_user_lastname;
            $_SESSION['user_role'] = $db_user_role;
            header("Location: ../admin");
        }
    }else{
            $Message = urlencode("Username and/or password is wrong!");
            header("Location: ../index.php?Message=".$Message);
    }
}
?>