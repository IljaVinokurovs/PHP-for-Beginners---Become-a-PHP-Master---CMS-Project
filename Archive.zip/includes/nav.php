<body>
       <div class="navbar navbar-inverse navbar-fixed-top">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="index.php">My Events</a>
    </div>
    <div class="navbar-collapse collapse" id="searchbar">
     
      <ul class="nav navbar-nav navbar-right">
        <li class="dropdown">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i>Browse by category<b class="caret"></b></a>
                <ul class="dropdown-menu">
                    <?php
                        $query = "SELECT * FROM categories";
                        $select_all_categories_query = mysqli_query($connection, $query);
                        while($row = mysqli_fetch_assoc($select_all_categories_query)){
                            $cat_title = $row['cat_title'];
                            $cat_id = $row['cat_id'];
                            echo "<li><a href='category.php?category=$cat_id'>{$cat_title}</a></li>";
                            echo "<li class='divider'></li>";
                        }
                    ?>
               </ul>
          </li>
        <?php
            if(isset($_SESSION['user_id'])){
                $username = $_SESSION['username'];
                echo '
                    <li id="userPage">
                      <a href="admin/index.php"><i class="icon-user"></i> My Admin Page</a>
                    </li>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i>' . $username . '<b class="caret"></b></a>
                        <ul class="dropdown-menu">
                            <li>
                                <a href="profile.php"><i class="fa fa-fw fa-user"></i> Profile</a>
                            </li>
                            <li class="divider"></li>
                            <li>
                                <a href="./includes/logout.php"><i class="fa fa-fw fa-power-off"></i> Log Out</a>
                            </li>
                        </ul>
                    </li>

                ';
            }else{
                echo '<li class="dropdown" multiple="multiple">
                        <a href="" class="dropdown-toggle" data-toggle="dropdown">Login</a>
                        <ul class="dropdown-menu" style="width:300px';
                            if(isset($_GET['Message'])){
                                echo '; display:block"';
                            }else{
                                echo '"';
                            }
                            echo '>
                            <li>
                                <div style="padding:5px">
                                    <h4>Login</h4>
                                    <form action="includes/login.php" method="post">
                                    <div class="form-group">
                                        <input name="username" type="text" placeholder="Enter Username" class="form-control">                        
                                    </div>
                                    <div class="input-group">
                                        <input type="password" name="user_password" placeholder="Enter Password" class="form-control">
                                        <span class="input-group-btn">
                                            <button class="btn btn-primary" name="login" type="submit">Login</button>
                                        </span>
                                    </div>
                                    <div>
                                        <h6>Dont have a user? <a href="registration.php">Register!</a></h6>
                                    </div>'; 
                                        
                                        if(isset($_GET['Message'])){
                                            $message = $_GET['Message'];
                                           ?>
                                           <div><h4 style="color:red"><?php echo $message; ?></h4></div>
                                           <?php
                                        }
                                     echo '   
                                    </form> <!--search form-->
                                    <!-- /.input-group -->
                                </div>
                            </li>
                        </ul>
                    </li>';
            }
          
          
            ?>
        </ul>
     
         <form class="navbar-form" action="search.php" method="post">
            <div class="form-group" style="display:inline;">
              <div class="input-group" style="display:table;">
                  <span class="input-group-btn" style="width:1%">
                    <button name="submit" class="btn btn-default" type="submit">
                        <span class="glyphicon glyphicon-search"></span>
                </button>
                </span>
                <input class="form-control" name="search" autocomplete="on" placeholder="Search Events Here" type="text">
              </div>
            </div>
          </form>
    </div><!--/.nav-collapse -->
  </div>
</div>