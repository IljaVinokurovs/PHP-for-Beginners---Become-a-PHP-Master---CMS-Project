<?php
include 'includes/header.php';
include 'includes/db.php';
include 'includes/nav.php';
?>

<!-- Carousel
================================================== -->
<div id="myCarousel" class="carousel slide" data-ride="carousel">
  <!-- Indicators -->
  <ol class="carousel-indicators">
    <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
    <li data-target="#myCarousel" data-slide-to="1"></li>
    <li data-target="#myCarousel" data-slide-to="2"></li>
  </ol>
  <div class="carousel-inner" role="listbox">
    <div class="item active">
      <img class="first-slide" src="images/sports.jpg" alt="First slide">
      <div class="container">
        <div class="carousel-caption">
          <h1>Featured category: SPOSTS</h1>
          <p>One of the most requested and popular event categories in our website is SPOSTS, it rengest from larger events like football and handball profecional games to smaller events where one could participate themself, like mounten climbing event where beginners can learn the basics of mounten climbing!</p>
          <p><a class="btn btn-lg btn-primary" href="#" role="button">Check out SPORT events near you</a></p>
        </div>
      </div>
    </div>
    <div class="item">
      <img class="second-slide" src="images/startup.jpg" alt="Second slide">
      <div class="container">
        <div class="carousel-caption">
          <h1>Startup Events</h1>
          <p>Want to start your own company or yoin other startups, this is a category for you!</p>
          <p><a class="btn btn-lg btn-primary" href="#" role="button">Check out STARTUP events newe you</a></p>
        </div>
      </div>
    </div>
    <div class="item">
      <img class="third-slide" src="images/winetasting.jpg" alt="Third slide">
      <div class="container">
        <div class="carousel-caption">
          <h1>Wine tasting</h1>
          <p>Like wine? Than this category is for you.</p>
          <p><a class="btn btn-lg btn-primary" href="#" role="button">Check out WINE TASTING events near you</a></p>
        </div>
      </div>
    </div>
  </div>
  <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div><!-- /.carousel -->
<!--three column text-->
<div class="container marketing">
    <div class="row">
        
    <?php
    $event_query_count = "SELECT * FROM events WHERE event_status = 'published'";
    $find_count = mysqli_query($connection, $event_query_count);
    $count = mysqli_num_rows($find_count);
    $count = ceil($count / 6); //if we want 5 events per page


    if(isset($_GET['page'])){
        $page = $_GET['page'];
    }else{
        $page = "";
    }
    if($page == "" || $page == 1){
        $page_1 = 0;
    }else{
        $page_1 = ($page * 6) - 6;
    }

    $query = "SELECT * FROM events WHERE event_status = 'published' ORDER BY event_id DESC LIMIT {$page_1}, 6";
    $select_all_events_query = mysqli_query($connection, $query);
    while($row = mysqli_fetch_assoc($select_all_events_query)){
        $event_id = $row['event_id'];
        $event_title = $row['event_title'];
        $event_organizer = $row['event_organizer'];
        $event_date = $row['event_date'];
        $event_picture = $row['event_picture'];
        $event_content = substr($row['event_content'], 0, 100);
        $event_status = $row['event_status'];
        $event_start_date = $row['event_start_date'];
        $event_end_date = $row['event_end_date'];
        $event_start_time = $row['event_start_time'];
        $event_end_time = $row['event_end_time'];
        $event_location = $row['event_location'];

        if($event_status == 'published'){
    ?> 
             <!-- Blog Entries Column -->      

            <!-- First Event Post -->
            
            <div class="col-lg-4">
                <a href="event.php?e_id=<?php echo $event_id?>"><img class="img-circle" src="<?php echo 'images/' . $event_picture; ?>" onerror="if (this.src != 'images/default.png') this.src = 'images/default.png';" width="140" height="140"></a>
                <h2><a style="color:#000000" href="event.php?e_id=<?php echo $event_id?>"><?php echo $event_title;?></a></h2>
                <hr>
                <p><strong>Event Starts: </strong> <span class="glyphicon glyphicon-time"></span> <?php echo $event_start_date . " " . $event_start_time;?></p>         
                <p><strong>Event Ends: </strong><span class="glyphicon glyphicon-time"></span> <?php echo $event_end_date . " " . $event_end_time;?></p>
                <p><strong>Event Location: </strong><?php echo $event_location ;?></p>  
              <p><a class="btn btn-default" href="event.php?e_id=<?php echo $event_id?>" role="button">View details &raquo;</a></p>
            </div><!-- /.col-lg-4 -->

       <?php

            }
        }
    ?>
</div>

<?php
include 'includes/sidebar.php';
?>
         <!-- Pager -->
    <ul class="pager">
        <?php
        for($i = 1; $i <= $count; $i++){
            if($i == $page){
                echo "<li><a class='active_link' href='index.php?page={$i}'>{$i}</a></li>";
            }else{
                echo "<li><a href='index.php?page={$i}'>{$i}</a></li>";
            }
        }
        ?>
    </ul>   
            

        </div>
        <!-- /.row -->

        <hr>
<?php
  include 'includes/footer.php';      
?>
