<?php
include 'includes/header.php';
include 'includes/db.php';
include 'includes/nav.php';
?>


    <!-- Page Content -->
    <div class="container">

        <div class="row">
            <div class="col-md-8"> 
                <?php
                if(isset($_GET['e_id']) && $_GET['e_id'] !== ""){
                    $the_event_id = $_GET['e_id'];
                    $the_event_id = mysqli_real_escape_string($connection, $the_event_id);
                
                    $query = "SELECT * FROM events WHERE event_id = $the_event_id";
                    $select_all_events_query = mysqli_query($connection, $query);
                    while($row = mysqli_fetch_assoc($select_all_events_query)){
                        $event_title = $row['event_title'];
                        $event_organizer = $row['event_organizer'];
                        $event_date = $row['event_date'];
                        $event_picture = $row['event_picture'];
                        $event_content = $row['event_content'];
                        $event_status = $row['event_status'];
                        $event_category_id = $row['event_category_id'];
                        $event_start_date = $row['event_start_date'];
                        $event_end_date = $row['event_end_date'];
                        $event_start_time = $row['event_start_time'];
                        $event_end_time = $row['event_end_time'];
                        $event_location = $row['event_location'];
                        if($event_status == 'published' || (isset($_SESSION['user_role']) && $_SESSION['user_role'] == 'Admin')){
                            $query = "UPDATE events SET event_views_count = event_views_count + 1 WHERE event_id = '{$the_event_id}'";
                            $update_view_count = mysqli_query($connection, $query);
                            
                            $query = "SELECT * FROM categories WHERE cat_id = {$event_category_id}"; //Selecting category name from category id hound in events so we can display it on top of the page
                            $select_event_category = mysqli_query($connection, $query);
                            $row = mysqli_fetch_assoc($select_event_category);
                            $event_category = $row['cat_title'];
                        ?>
                        <small><a style="color: #6c6c6c" href="index.php">HOME</a> / <a style="color: #6c6c6c" href="#">EVENT AREA</a> / <a style="color: #6c6c6c" href="category.php?category=<?php echo $event_category_id;?>"><?php echo strtoupper($event_category);?></a> / <a style="color: #6c6c6c" href="#"><?php echo strtoupper($event_title);?></a></small>
                     <!-- Event Entries Column -->      

                        <!-- First Event Post -->
                        <a href=""><img class="img-responsive center-block" src="<?php echo 'images/' . $event_picture; ?>" onerror="if (this.src != 'images/default.png') this.src = 'images/default.png';" ?>"></a>
                        <h1 class="page-header">
                            <a href=""><?php echo $event_title;?></a>
                        </h1>
                        <p class="lead">
                            Organized by <a href="organizer_events.php?organizer=<?php echo $event_organizer; ?>"><?php echo $event_organizer;?></a>
                        </p>
                        <p><strong>Event Starts: </strong> <span class="glyphicon glyphicon-time"></span> <?php echo $event_start_date . " " . $event_start_time;?></p>         
                        <p><strong>Event Ends: </strong><span class="glyphicon glyphicon-time"></span> <?php echo $event_end_date . " " . $event_end_time;?></p>
                        <p><strong>Event Location: </strong><?php echo $event_location ;?></p>    
                        <hr>
                        <pp><strong>What to expect</strong></pp>
                        <p><?php echo $event_content;?></p>

                        <hr>


                   <?php
                        }
                    }   
                    }else{
                    header("Location: index.php");
                }
                ?>

                <!-- Event Comments -->
                <?php
                if($event_status == 'published' || (isset($_SESSION['user_role']) && $_SESSION['user_role'] == 'Admin')){
                    if(isset($_POST['create_comment'])){
                        $comment_author = $_POST['comment_author'];
                        $comment_author = mysqli_real_escape_string($connection, $comment_author);
                        $comment_email = $_POST['comment_email'];
                        $comment_email = mysqli_real_escape_string($connection, $comment_email);
                        $comment_content = $_POST['comment_content'];
                        $comment_content = mysqli_real_escape_string($connection, $comment_content);
    //                    missing status
                        $comment_date = date('Y-m-d H:i:s');
                        $comment_event_id = $the_event_id;
                        if(!empty($comment_author) && !empty($comment_email && !empty($comment_content))){
                            $query = "INSERT INTO comments (comment_author, comment_email, comment_content, comment_status, comment_date, comment_event_id) VALUES ('{$comment_author}', '{$comment_email}', '{$comment_content}', 'unapproved', now(), {$comment_event_id})";
                            $add_comment = mysqli_query($connection, $query);
                            if($add_comment){
                                echo 'Your comment was submitted and is pending approval';
                            }else{
                                die("QUERRY FAILED" . mysqli_error($connection));
                            }
    //                        $query = "UPDATE events SET event_comment_count = event_comment_count + 1 WHERE event_id = $the_event_id";
    //                        $update_comment_count = mysqli_query($connection, $query);   
                        }else{
                            echo "<script>alert('Author, Email and Content fields cannot be empty')</script>";
                        }
                    }
                    ?>
                    <!-- Comments Form -->
                    <div class="well">
                        <h4>Leave a Comment:</h4>
                        <form action="event.php?e_id=<?php echo $the_event_id;?>" method="post" role="form">
                            <div class="form-group">
                                <input type="text" class="form-control" placeholder="Organizer Name" name="comment_organizer">
                            </div>
                            <div class="form-group">
                                <input type="email" class="form-control" placeholder="Email" name="comment_email">
                            </div>
                            <div class="form-group">
                                <textarea name="comment_content" placeholder="Insert Your Comment Here..." class="form-control" rows="3"></textarea>
                            </div>
                            <button type="submit" name="create_comment" class="btn btn-primary">Submit</button>
                        </form>
                    </div>

                    <hr>

                    <!-- Posted Comments -->

                    <!-- Comment -->
                    <?php
                        if(isset($_GET['e_id'])){
                            $comment_event_id = $_GET['e_id'];

                            $query = "SELECT * FROM comments WHERE comment_event_id = $comment_event_id AND comment_status = 'approved' ORDER BY comment_id DESC";
                            $select_all_comments_query = mysqli_query($connection, $query);
                            while($row = mysqli_fetch_assoc($select_all_comments_query)){
                                $comment_author = $row['comment_author'];
                                $comment_date = $row['comment_date'];
                                $comment_content = $row['comment_content'];

                    ?>
                                <div class="media">
                                    <a class="pull-left" href="#">
                                        <img class="media-object" src="http://placehold.it/64x64" alt="">
                                    </a>
                                    <div class="media-body">
                                        <h4 class="media-heading"><?php echo $comment_author;?>
                                            <small><?php echo $comment_date; ?></small>
                                        </h4>
                                        <?php echo $comment_content;?>
                                    </div>
                                </div>       
                    <?php
                            }
                        }
                }
                    ?>


                <!-- Comment -->
<!--
                <div class="media">
                    <a class="pull-left" href="#">
                        <img class="media-object" src="http://placehold.it/64x64" alt="">
                    </a>
                    <div class="media-body">
                        <h4 class="media-heading">Start Bootstrap
                            <small>August 25, 2014 at 9:30 PM</small>
                        </h4>
                        Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin commodo. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis in faucibus.
-->
                        <!-- Nested Comment -->
<!--
                        <div class="media">
                            <a class="pull-left" href="#">
                                <img class="media-object" src="http://placehold.it/64x64" alt="">
                            </a>
                            <div class="media-body">
                                <h4 class="media-heading">Nested Start Bootstrap
                                    <small>August 25, 2014 at 9:30 PM</small>
                                </h4>
                                Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin commodo. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis in faucibus.
                            </div>
                        </div>
-->
                        <!-- End Nested Comment -->
<!--
                    </div>
                </div>
-->


            </div>

<?php // event sidebar widget
include 'includes/sidebar.php';
?>
            
            

        </div>
        <!-- /.row -->

        <hr>
<?php
  include 'includes/footer.php';      
?>
