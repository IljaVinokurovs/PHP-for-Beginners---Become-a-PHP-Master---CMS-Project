<?php
include 'includes/header.php';
include 'includes/db.php';
include 'includes/nav.php';
?>


    <!-- Page Content -->
    <div class="container">

        <div class="row">
            <div class="col-md-8"> 

                 <?php
                if(isset($_POST['search'])){
                    $search = $_POST['search'];
                    $search = mysqli_real_escape_string($connection, $search);//prevents sql injection
                    $query = "SELECT * FROM events WHERE event_tags LIKE '%$search%'";
                    $search_query = mysqli_query($connection, $query);
                    if(!$search_query){
                        die('QUERY FAILED' . mysqli_error($connection));
                        
                    }
                    else{
                        $count = mysqli_num_rows($search_query);
                        if($count == 0){
                            echo '<h1>THERE WAS NO MATCH</h1>';
                        }
                        else{
                    while($row = mysqli_fetch_assoc($search_query)){
                        $event_title = $row['event_title'];
                        $event_organizer = $row['event_organizer'];
                        $event_date = $row['event_date'];
                        $event_picture = $row['event_picture'];
                        $event_content = $row['event_content'];
                        
                 ?>
             <!-- Event Entries Column -->      
                <h1 class="page-header">
                    Page Heading
                    <small>Secondary Text</small>
                </h1>

                <!-- First Event Post -->
                <h2>
                    <a href="#"><?php echo $event_title;?></a>
                </h2>
                <p class="lead">
                    by <a href="index.php"><?php echo $event_organizer;?></a>
                </p>
                <p><span class="glyphicon glyphicon-time"></span> <?php echo $event_date;?></p>
                <hr>
                <a href=""><img class="img-responsive" src="<?php echo 'images/' . $event_picture; ?>" alt="<?php echo $event_title; ?>"></a>
                <hr>
                <p><?php echo $event_content;?></p>
                <a class="btn btn-primary" href="#">Read More <span class="glyphicon glyphicon-chevron-right"></span></a>

                <hr>


                   <?php
                    }
                        }
                    }
                }
                ?>
                   
                   


                <!-- Pager -->
                <ul class="pager">
                    <li class="previous">
                        <a href="#">&larr; Older</a>
                    </li>
                    <li class="next">
                        <a href="#">Newer &rarr;</a>
                    </li>
                </ul>

            </div>

<?php
include 'includes/sidebar.php';
?>
            
            

        </div>
        <!-- /.row -->

        <hr>
<?php
  include 'includes/footer.php';      
?>
