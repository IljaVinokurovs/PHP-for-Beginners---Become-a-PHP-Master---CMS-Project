<?php
include 'includes/header.php';
include 'includes/db.php';
include 'includes/nav.php';
?>

<?php
if(isset($_GET['organizer'])){
    $organizer = $_GET['organizer'];
}
?>


    <!-- Page Content -->
    <div class="container">

        <div class="row">
            <div class="col-md-8"> 
                <h1 class="page-header">
                    Page Heading
                    <small>Secondary Text</small>
                </h1>
                <?php
                    $query = "SELECT * FROM events WHERE event_status = 'published' AND event_organizer = '{$organizer}'";
                    $select_all_events_query = mysqli_query($connection, $query);
                    while($row = mysqli_fetch_assoc($select_all_events_query)){
                        $event_id = $row['event_id'];
                        $event_title = $row['event_title'];
                        $event_organizer = $row['event_organizer'];
                        $event_date = $row['event_date'];
                        $event_picture = $row['event_picture'];
                        $event_content = substr($row['event_content'], 0, 100);
                        $event_status = $row['event_status'];
                        
                        if($event_status == 'published'){
                ?> 
                         <!-- Event Entries Column -->      

                        <!-- First Event Post -->
                        <h2>
                            <a href="event.php?e_id=<?php echo $event_id?>"><?php echo $event_title;?></a>
                        </h2>
                        <p class="lead">
                            by <a href="organizer_events.php?organizer=<?php echo $event_organizer; ?>"><?php echo $event_organizer;?></a>
                        </p>
                        <p><span class="glyphicon glyphicon-time"></span> <?php echo $event_date;?></p>
                        <hr>
                        <a href="event.php?e_id=<?php echo $event_id?>"><img class="img-responsive" src="<?php echo 'images/' . $event_picture; ?>" alt="<?php echo $event_title; ?>"></a>
                        <hr>
                        <p><?php echo $event_content;?></p>
                        <a class="btn btn-primary" href="event.php?e_id=<?php echo $event_id?>">Read More <span class="glyphicon glyphicon-chevron-right"></span></a>

                        <hr>


                   <?php
                            
                        }
                    }
                ?>

                <!-- Pager -->
                <ul class="pager">
                    <li class="previous">
                        <a href="#">&larr; Older</a>
                    </li>
                    <li class="next">
                        <a href="#">Newer &rarr;</a>
                    </li>
                </ul>

            </div>

<?php
include 'includes/sidebar.php';
?>
            
            

        </div>
        <!-- /.row -->

        <hr>
<?php
  include 'includes/footer.php';      
?>
