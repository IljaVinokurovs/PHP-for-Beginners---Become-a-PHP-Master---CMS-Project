<?php  include "includes/db.php"; ?>
 <?php  include "includes/header.php"; ?>


    <!-- Navigation -->
    
    <?php  include "includes/nav.php"; ?>

<?php
if(isset($_POST['submit'])){
    $to = "el_ninio@inbox.lv";
    $header = "From: " . $_POST['email'] . "\r\n";// headers can also include cc
   // $headers = "From: webmaster@example.com\r\n"
    $subject = $_POST['subject'];
    $body = $_POST['body'];
    $body = wordwrap($body);
    if(!empty($to) && !empty($subject) && !empty($body)){
        mail($to, $subject, $body, $header); // need new line sequence for header , $from\r\n
        $message = "Email has been submitted";
    }else{
        $message = "Fields cannot be empty";
    }
}else{
    $message = null;
}
?>
 
    <!-- Page Content -->
    <div class="container">
    
<section id="login">
    <div class="container">
        <div class="row">
            <div class="col-xs-6 col-xs-offset-3">
                <div class="form-wrap">
                <h1>Contact</h1>
                    <form role="form" action="" method="post" id="login-form" autocomplete="off">
                       <h6 class="text-center"><?php echo $message; ?></h6>
                         <div class="form-group">
                            <label for="email" class="sr-only">Email</label>
                            <input type="email" name="email" id="email" class="form-control" placeholder="Enter your email here">
                        </div>
                        <div class="form-group">
                            <label for="subject" class="sr-only">Subject</label>
                            <input type="text" name="subject" id="subject" class="form-control" placeholder="Subject">
                        </div>
                         <div class="form-group">
                            <label for="body" class="sr-only">Message</label>
                            <textarea name="body" id="body" cols="30" rows="10" class="form-control" placeholder="Enter your meesage here.."></textarea>
                        </div>
                
                        <input type="submit" name="submit" id="btn-login" class="btn btn-custom btn-lg btn-block" value="Submit">
                    </form>
                 
                </div>
            </div> <!-- /.col-xs-12 -->
        </div> <!-- /.row -->
    </div> <!-- /.container -->
</section>


        <hr>



<?php include "includes/footer.php";?>
