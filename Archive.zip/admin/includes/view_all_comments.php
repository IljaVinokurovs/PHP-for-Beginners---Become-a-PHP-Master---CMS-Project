<table class="table table-bordered table-hover">
    <thead>
        <tr>
            <th>ID</th>
            <th>Author</th>
            <th>Comment</th>
            <th>Email</th>
            <th>Status</th>
            <th>In Responce to</th>
            <th>Date</th>
            <th>Approve</th>
            <th>Unapprove</th>
            <th>Delete</th>
        </tr>
    </thead>
    <tbody>
        <?php
        if(isset($_GET['id'])){
            $comment_event_id = $_GET['id'];
            
            $query = "SELECT * FROM comments WHERE comment_event_id = {$comment_event_id}";
            $select_comment = mysqli_query($connection, $query);
            while($row = mysqli_fetch_assoc($select_comment)){
                $comment_id = $row['comment_id'];
                $comment_author = $row['comment_author'];
                $comment_content = $row['comment_content'];
                $comment_email = $row['comment_email'];
                $comment_status = $row['comment_status'];
                $in_responce_to = $row['comment_event_id'];
                $comment_date = $row['comment_date'];

                echo "<tr><td>$comment_id</td>";
                echo "<td>$comment_author</td>";
                echo "<td>$comment_content</td>";
                echo "<td>$comment_email</td>";
                echo "<td>$comment_status</td>";
                $query = "SELECT * FROM events WHERE event_id = {$in_responce_to}";
                $select_title = mysqli_query($connection, $query); 
                while($row = mysqli_fetch_assoc($select_title)){
                    $event_id = $row['event_id'];
                    $event_title = $row['event_title'];
                }
                echo "<td><a href='../event.php?e_id={$event_id}'>{$event_title}</a></td>";
                echo "<td>$comment_date</td>";
                echo "<td><a href='comments.php?approve={$comment_id}&id={$comment_event_id}'>Approve</a></td>";
                echo "<td><a href='comments.php?unapprove={$comment_id}&id={$comment_event_id}'>Unapprove</a></td>";
                echo "<td><a onClick=\"javascript: return confirm('Are you sure?');\" href='comments.php?delete={$comment_id}&id={$comment_event_id}'>Delete</a></td></tr>";                                    
            }
        
            if(isset($_GET['delete'])){
                $comment_id = $_GET['delete'];
                $query = "DELETE FROM comments WHERE comment_id = {$comment_id}";
                $delete_comment = mysqli_query($connection, $query);
                header("Location: comments.php?id=$comment_event_id");
            }
            if(isset($_GET['approve'])){
                $comment_id = $_GET['approve'];
                $query = "UPDATE comments SET comment_status = 'approved' WHERE comment_id = {$comment_id};";
                $approve_comment = mysqli_query($connection, $query);
                header("Location: comments.php?id=$comment_event_id");
            }
            if(isset($_GET['unapprove'])){
                $comment_id = $_GET['unapprove'];
                $query = "UPDATE comments SET comment_status = 'unapproved' WHERE comment_id = {$comment_id};";
                $unapprove_comment = mysqli_query($connection, $query);
                header("Location: comments.php?id=$comment_event_id");
            }
        }else{
            $query = "SELECT * FROM comments";
            $select_comment = mysqli_query($connection, $query);
            while($row = mysqli_fetch_assoc($select_comment)){
                $comment_id = $row['comment_id'];
                $comment_author = $row['comment_author'];
                $comment_content = $row['comment_content'];
                $comment_email = $row['comment_email'];
                $comment_status = $row['comment_status'];
                $in_responce_to = $row['comment_event_id'];
                $comment_date = $row['comment_date'];

                echo "<tr><td>$comment_id</td>";
                echo "<td>$comment_author</td>";
                echo "<td>$comment_content</td>";
                echo "<td>$comment_email</td>";
                echo "<td>$comment_status</td>";
                $query = "SELECT * FROM events WHERE event_id = {$in_responce_to}";
                $select_title = mysqli_query($connection, $query); 
                while($row = mysqli_fetch_assoc($select_title)){
                    $event_id = $row['event_id'];
                    $event_title = $row['event_title'];
                }
                echo "<td><a href='../event.php?e_id={$event_id}'>{$event_title}</a></td>";
                echo "<td>$comment_date</td>";
                echo "<td><a href='comments.php?approve={$comment_id}'>Approve</a></td>";
                echo "<td><a href='comments.php?unapprove={$comment_id}'>Unapprove</a></td>";
                echo "<td><a onClick=\"javascript: return confirm('Are you sure?');\" href='comments.php?delete={$comment_id}'>Delete</a></td></tr>";                                    
                }
            
            if(isset($_GET['delete'])){
                $comment_id = $_GET['delete'];
                $query = "DELETE FROM comments WHERE comment_id = {$comment_id}";
                $delete_comment = mysqli_query($connection, $query);
                header("Location: comments.php");
            }
            if(isset($_GET['approve'])){
                $comment_id = $_GET['approve'];
                $query = "UPDATE comments SET comment_status = 'approved' WHERE comment_id = {$comment_id};";
                $approve_comment = mysqli_query($connection, $query);
                header("Location: comments.php");
            }
            if(isset($_GET['unapprove'])){
                $comment_id = $_GET['unapprove'];
                $query = "UPDATE comments SET comment_status = 'unapproved' WHERE comment_id = {$comment_id};";
                $unapprove_comment = mysqli_query($connection, $query);
                header("Location: comments.php");
            }
            
            }
        ?>
    </tbody>
</table>