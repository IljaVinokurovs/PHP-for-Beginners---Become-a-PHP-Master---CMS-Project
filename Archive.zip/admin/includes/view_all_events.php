<?php
include "includes/delete_modal.php";

if(isset($_POST['checkBoxArray'])){
    foreach($_POST['checkBoxArray'] as $eventValueID){
        $bulk_options = $_POST['bulk_options'];
        switch($bulk_options){
            case 'published':
                $query = "UPDATE events SET event_status = '{$bulk_options}' WHERE event_id = {$eventValueID}";
                $update_to_published = mysqli_query($connection, $query);
            break;
            case 'draft':
               $query = "UPDATE events SET event_status = '{$bulk_options}' WHERE event_id = {$eventValueID}";
               $update_to_draft = mysqli_query($connection, $query);
            break;
            case 'delete':
               $query = "DELETE FROM events WHERE event_id = {$eventValueID}";
               $delete_event = mysqli_query($connection, $query);
            break;
            default:
            break;
        }
    }
}
?>
<?php
if(isset($_GET['message'])){
    echo "<p class='bg-success'>Event was succesfuly deleted</p>";
}
?>
<form action="" method="post">



<table class="table table-bordered table-hover">
   <div id="bulkOptionsContainer" class="col-xs-4" style="padding: 0px; margin-bottom: 5px;">
       <select class="form-control" name="bulk_options" id="">
           <option value="">Select Option</option>
           <option value="published">Publish All</option>
           <option value="draft">Draft All</option>
           <option value="delete">Delete All</option>
       </select>
   </div>
   <div class="col-xs-4">
       <input type="submit" name="submit" class="btn btn-success" value="Apply">
       <a href="events.php?source=add_events" class="btn btn-primary">Add New Event</a>
   </div>
    <thead>
        <tr>
            <th><input id="selectAllBoxes" type="checkbox"></th>
            <th>ID</th>
            <th>Organizer</th>
            <th>Title</th>
            <th>Category</th>
            <th>Status</th>
            <th>Images</th>
            <th>Tags</th>
            <th>Comments</th>
            <th>View Count</th>
            <th>Date</th>
            <th>View Event</th>
            <th>Edit</th>
            <th>Delete</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $query = "SELECT * FROM events ORDER BY event_id DESC";
        $select_events = mysqli_query($connection, $query);
        while($row = mysqli_fetch_assoc($select_events)){
            $event_id = $row['event_id'];
            $event_organizer = $row['event_organizer'];
            $event_title = $row['event_title'];
            $event_cat = $row['event_category_id'];
            $event_status = $row['event_status'];
            $event_image = $row['event_picture'];
            $event_tags = $row['event_tags'];
            $event_date = $row['event_date'];
            $event_views_count = $row['event_views_count'];

            ?><tr><td><input name="checkBoxArray[]" value="<?php echo $event_id; ?>" class="checkBoxes" type="checkbox"></td>
            <?php
            echo "<td>$event_id</td>";
            echo "<td>$event_organizer</td>";
            echo "<td>$event_title</td>";
            
            $query = "SELECT * FROM categories WHERE cat_id = {$event_cat}";
            $select_categories_id = mysqli_query($connection, $query); 
            while($row = mysqli_fetch_assoc($select_categories_id)){
                $cat_id = $row['cat_id'];
                $cat_title = $row['cat_title'];
            }
            echo "<td>$cat_title</td>";
            echo "<td>$event_status</td>";
            echo "<td><img src='../images/$event_image' width='90' alt='No Image'></td>";
            echo "<td>$event_tags</td>";
            $query = "SELECT * FROM comments WHERE comment_event_id = {$event_id}";
            $count_query = mysqli_query($connection, $query);
            $comment_count  = mysqli_num_rows($count_query);
            echo "<td><a href='comments.php?id=$event_id'>$comment_count</a></td>";
            echo "<td>$event_views_count</td>";
            echo "<td>$event_date</td>";
            echo "<td><a href='../event.php?e_id={$event_id}'>View Event</a></td>";
            echo "<td><a href='events.php?source=edit_event&e_id={$event_id}'>Edit</a></td>";
            echo "<td><a rel='$event_id' href='javascript:void(0)' class='delete_link'>Delete</a></td></tr>";                                    
//            echo "<td><a  onClick=\"javascript: return confirm('Are you sure?'); \" href='events.php?delete={$event_id}'>Delete</a></td></tr>";                                    
        }
        
//        
//        <script type="text/javascript">
//function confirm_delete() {
//  return confirm('are you sure?');
//}
//</script>
//...
//<a href="whatever" onclick="return confirm_delete()"><img ...></a>
        ?>
    </tbody>
</table>
</form>
<?php
if(isset($_GET['delete'])){
    $the_event_id = $_GET['delete'];
    $query = "DELETE FROM events WHERE event_id = {$the_event_id}";
    $delete_query = mysqli_query($connection, $query);
    header("Location: events.php?message=deleted");
}
?>


<script>
$(document).ready(function(){
   $(".delete_link").on('click', function(){
       var id = $(this).attr("rel");
       var delete_url = "events.php?delete="+ id +" ";
       $(".modal_delete_link").attr("href", delete_url);
       $("#myModal").modal('show');
   });
});
</script>