<?php
if(isset($_POST['create_event'])){
    $event_title = $_POST['event_title'];
    $event_title = mysqli_real_escape_string($connection,$event_title);
    $event_category_id = $_POST['event_category'];
    $event_category_id = mysqli_real_escape_string($connection, $event_category_id);
    $event_organizer = $_POST['event_organizer'];
    $event_organizer - mysqli_real_escape_string($connection, $event_organizer);
    $event_status = $_POST['event_status'];
    $event_status = mysqli_real_escape_string($connection, $event_status);
    $event_tags = $_POST['event_tags'];
    $event_tags = mysqli_real_escape_string($connection, $event_tags);
    $event_content = $_POST['event_content'];
    $event_content = mysqli_real_escape_string($connection, $event_content);
    $event_date = date('d-m-y');
    $event_start_date = $_POST['start_date'];
    $event_end_date = $_POST['end_date'];
    $event_start_time = $_POST['start_time'];
    $event_end_time = $_POST['end_time'];
    $event_location = $_POST['event_location'];
    $event_privacy = $_POST['event_privacy'];
    $event_repeat = $_POST['event_repeat'];
    $event_cost = $_POST['event_cost'];
    $event_url = $_POST['event_url'];
    
    $event_image = $_FILES['image']['name'];
    $event_image_temp = $_FILES['image']['tmp_name'];
    $event_image_temp = $_FILES['image']['tmp_name'];
    move_uploaded_file($event_image_temp, "../images/$event_image");
    
    $query = "INSERT INTO events (event_category_id, event_title, event_organizer, event_date, event_start_date, event_end_date, event_start_time, event_end_time, event_location, event_picture, event_content, event_tags, event_status, event_privacy, event_repeat, event_cost, event_url) VALUES ({$event_category_id},'{$event_title}','{$event_organizer}',now(), '{$event_start_date}', '{$event_end_date}', '{$event_start_time}', '{$event_end_time}','{$event_location}','{$event_image}','{$event_content}','{$event_tags}','{$event_status}', '{$event_privacy}','{$event_repeat}','{$event_cost}', '{$event_url}' )";
    
    $create_event_quary = mysqli_query($connection, $query);
    if($create_event_quary){
        echo "<p class='bg-success'>Event was succesfuly added!</p>";
    }
    else{
        die('Query failed' . mysqli_error($connection));
    }
}
print_r($_POST);
?>
  
<form action="" method="post" enctype="multipart/form-data">
    <div class="form-group">
        <label for="title"> Title</label>
        <input type="text" class="form-control" name="event_title">
    </div>
    <div class="form-group">
        <label for="event_organizer">Event Organizer</label>
        <input type="text" class="form-control" name="event_organizer" value="<?php echo $_SESSION['username']?>">
    </div>
    
    <div class="form-group">
        <label for="event_category">Event Category</label>
        <select name="event_category" id="">
            <?php
            $query = "SELECT * FROM categories";
            $select_categories = mysqli_query($connection, $query);
            confirmQuery($select_categories);
            while($row = mysqli_fetch_assoc($select_categories)){
                $cat_id = $row['cat_id'];
                $cat_title = $row['cat_title'];
                echo "<option value={$cat_id}>{$cat_title}</option>";
            }
            ?>
        </select>
    </div>

    <div class="form-group">
           <label for="event_status">Event Status</label>
            <select name="event_status" id="">
            <option value="draft">Draft</option>
            <option value="published">Published</option>
        </select>
            <label for="event_privacy">Event Publicity</label>
            <select name="event_privacy" id="">
                <option value="public">Public</option>
                <option value="private">Private</option>
        </select>
            <label for="event_repeat">Event Repeats?</label>
            <select name="event_repeat" id="">
                <option value="no">No</option>
                <option value="weekly">Weekly</option>
                <option value="monthly">Monthly</option>
                <option value="yearly">Yearly</option>
            </select>
    </div>
     
   
     <div class="form-group">
        <label for="image">Event Image</label>
        <input type="file" name="image">
    </div>
<!--    Start date of the event-->
      <div class="row form-group">
        <div class="col-xs-2">
            <label for="start_date">Start Date</label> 
            <input type="date" class="form-control" name="start_date" id="start_date">
        </div>
        <!--    Start time of the event-->
<?php        
$today = new DateTime();

// Make an empty array to contain the hours
$aHours = array();

// Make another DateTime object with the current date and time
$oStart = new DateTime('now');

// Set current time to midnight
$oStart->setTime(0, 0);

// Clone DateTime object (This is like 'copying' it)
$oEnd = clone $oStart;

// Add 1 day (24 hours)
$oEnd->add(new DateInterval("P1D"));

// Add each hour to an array
while ($oStart->getTimestamp() < $oEnd->getTimestamp()) {
    $aHours[] = $oStart->format('H');
    $oStart->add(new DateInterval("PT1H"));
}

// Create an array with halfs
$halfs = array(
    '0',
    '30',
);

// Get the current quarter
//$currentHalf = $today->format('i') - ($today->format('i') % 30);
$default = -1; //currenthalf is now default
?>
        <div class="col-xs-2">
            <label for="start_time">Start Time</label>
            <select class="form-control" style="line-height: 34px" name="start_time" id="start_time">
        
                <option value="-1">Choose a time</option>
                    <?php foreach ($aHours as $hour): ?>
                        <?php foreach ($halfs as $half): ?>
                <option value="<?php echo sprintf("%02d:%02d", $hour, $half); ?>" <?php echo ($hour == $today->format('H') && $half == $default) ? 'selected' : ''; ?>>
                <?php echo sprintf("%02d:%02d", $hour, $half); ?>
                </option>
                        <?php endforeach; ?>
                    <?php endforeach; ?>
            </select>

        </div>
        <!--    End date of the event-->
        <div class="col-xs-2"> 
            <label for="end_date">End Date</label> 
            <input type="date" class="form-control" name="end_date" id="end_date">
        </div>
        <!--    End time of the event-->
        <div class="col-xs-2">
            <label for="end_time">End Time</label>
            <select class="form-control" name="end_time" id="end_time">             
            <option value="-1" selected="-1">Choose a time</option>
                <?php foreach ($aHours as $hour): ?>
                <?php foreach ($halfs as $half): ?>
            <option value="<?php echo sprintf("%02d:%02d", $hour, $half); ?>" <?php echo ($hour == $today->format('H') && $half == $default) ? 'selected' : ''; ?>>
                <?php echo sprintf("%02d:%02d", $hour, $half); ?>
            </option>
                <?php endforeach; ?>
                <?php endforeach; ?>

            </select>
        </div> 
        <!--   Cost of the event-->
        <div class="col-xs-3"> 
            <label for="end_date">Event Price in DKK</label> 
            <input type="text" class="form-control" name="event_cost" id="event_cost" placeholder="Leave blank for a Free Event">
        </div>
        
    </div>    

    <!--   Tags of the event-->
    <div class="form-group">
        <label class="control-label"for="event_tags">Event Tags</label>
        <input type="text" class="form-control" name="event_tags">
    </div>
    
     <!--   Location of the event-->
     <script src="js/autocomplete_places.js"></script>
     <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyB6Y8h5biQ5Jh3FLMhzDPUEn0C8G3d6mrA&libraries=places&callback=initAutocomplete"
        async defer></script>

    <div class="form-group">
       
        <label class="control-label"for="event_location">Event Location</label>
        <input id="autocomplete" class="form-control" placeholder="Enter your address"
             onFocus="geolocate()" type="text" name="event_location">

    </div>
    <div class="form-group">
        <label for="event_url">Event Web Site</label>
        <input type="text" class="form-control" name="event_url" placeholder="Insert link here">
    </div>
    <div class="form-group">
        <label for="event_content">Event Description</label>
        <textarea name="event_content" id="" cols="30" rows="8" class="form-control"></textarea>
    </div>
        
    <div>
        <input class="btn btn-primary" type="submit" name="create_event" value="Publish Event">
    </div>
</form>