<?php
if(isset($_POST['add_user'])){
    $username = $_POST['username'];
    $username = mysqli_real_escape_string($connection,$username);
    $user_password = $_POST['user_password'];
    $user_password = mysqli_real_escape_string($connection, $user_password);
    $user_role = $_POST['user_role'];
    $user_role - mysqli_real_escape_string($connection, $user_role);
    $user_firstname = $_POST['user_firstname'];
    $user_firstname = mysqli_real_escape_string($connection, $user_firstname);
    $user_lastname = $_POST['user_lastname'];
    $user_lastname = mysqli_real_escape_string($connection, $user_lastname);
    $user_email = $_POST['user_email'];
    $user_email = mysqli_real_escape_string($connection, $user_email);
    
    $user_image = $_FILES['user_image']['name'];
    $user_image_temp = $_FILES['user_image']['tmp_name'];
    move_uploaded_file($user_image_temp, "../images/$user_image");
    
    $hashed_password = password_hash($user_password, PASSWORD_BCRYPT, array('cost' => 12));
    
    $query = "INSERT INTO users (username, user_password, user_role, user_firstname, user_lastname, user_email, user_image) VALUES ('{$username}','{$hashed_password}','{$user_role}','{$user_firstname}','{$user_lastname}','{$user_email}','{$user_image}')";
    
    $add_user_quary = mysqli_query($connection, $query);
    if($add_user_quary){
        echo "<p class='bg-success'>User was succesfuly added!</p>";
    }
    else{
        die('Query failed: ' . mysqli_error($connection));
    }
}
?>
  
<form action="" method="post" enctype="multipart/form-data">
    <div class="form-group">
        <label for="username">Username</label>
        <input type="text" class="form-control" name="username">
    </div>
    <div class="form-group">
        <label for="user_password">Password</label>
        <input type="password" class="form-control" name="user_password">
    </div>
    <div class="form-group">
        <label for="user_role">User Role:</label>
        <select name="user_role" id="">
            <option value="Subscriber">Subscriber</option>
            <option value="Admin">Admin</option>
        </select>
    </div> 
    <div class="form-group">
        <label for="user_firstname">Firstname</label>
        <input type="text" class="form-control" name="user_firstname">
    </div>
     <div class="form-group">
        <label for="user_lastname">Lastname</label>
        <input type="text" class="form-control" name="user_lastname">
    </div>
     <div class="form-group">
        <label for="user_image">User Image</label>
        <input type="file" name="user_image">
    </div>
     <div class="form-group">
        <label for="user_email">Email</label>
        <input type="email" class="form-control" name="user_email">
    </div>
    <div>
        <input class="btn btn-primary" type="submit" name="add_user" value="Add User">
    </div>
</form>