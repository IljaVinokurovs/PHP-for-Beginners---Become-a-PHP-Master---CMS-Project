<?php
if(isset($_GET['e_id'])){
    $the_event_id = $_GET['e_id'];


    $query = "SELECT * FROM events WHERE event_id = $the_event_id";
    $select_events_by_id = mysqli_query($connection, $query);
    while($row = mysqli_fetch_assoc($select_events_by_id)){
        $event_id = $row['event_id'];
        $event_organizer = $row['event_organizer'];
        $event_title = $row['event_title'];
        $event_category_id = $row['event_category_id'];
        $event_status = $row['event_status'];
        $event_image = $row['event_picture'];
        $event_tags = $row['event_tags'];
        $event_date = $row['event_date'];
        $event_content = $row['event_content'];
        $event_start_date = $row['event_start_date'];
        $event_end_date = $row['event_end_date'];
        $event_start_time = $row['event_start_time'];
        $event_end_time = $row['event_end_time'];
        $event_cost = $row['event_cost'];
        $event_location = $row['event_location'];
        $event_url = $row['event_url'];
        $event_privacy = $row['event_privacy'];
        $event_repeat = $row['event_repeat'];
    }
}

if(isset($_POST['update_event'])){
    $event_title = $_POST['event_title'];
    $event_title = mysqli_real_escape_string($connection,$event_title);
    $event_category_id = $_POST['event_category'];// if this is set we have event_category_id not string
    $event_category_id = mysqli_real_escape_string($connection, $event_category_id);
    $event_organizer = $_POST['event_organizer'];
    $event_organizer = mysqli_real_escape_string($connection, $event_organizer);
    $event_status = $_POST['event_status'];
    $event_status = mysqli_real_escape_string($connection, $event_status);
    $event_tags = $_POST['event_tags'];
    $event_tags = mysqli_real_escape_string($connection, $event_tags);
    $event_content = $_POST['event_content'];
    $event_content = mysqli_real_escape_string($connection, $event_content);
    $event_start_date = $_POST['start_date'];
    $event_start_date = mysqli_real_escape_string($connection, $event_start_date);
    $event_end_date = $_POST['end_date'];
    $event_end_date = mysqli_real_escape_string($connection, $event_end_date);
    $event_start_time = $_POST['start_time'];
    $event_start_time = mysqli_real_escape_string($connection, $event_start_time);
    $event_end_time = $_POST['end_time'];
    $event_end_time = mysqli_real_escape_string($connection, $event_end_time);
    $event_cost = $_POST['event_cost'];
    $event_cost = mysqli_real_escape_string($connection, $event_cost);
    $event_location = $_POST['event_location'];
    $event_location = mysqli_real_escape_string($connection, $event_location);
    $event_url = $_POST['event_url'];
    $event_url = mysqli_real_escape_string($connection, $event_url);
    $event_privacy = $_POST['event_privacy'];
    $event_privacy = mysqli_real_escape_string($connection, $event_privacy);
    $event_repeat = $_POST['event_repeat'];
    $event_repeat = mysqli_real_escape_string($connection, $event_repeat);


    $event_image = $_FILES['image']['name'];
    $event_image_temp = $_FILES['image']['tmp_name'];
    move_uploaded_file($event_image_temp, "../images/$event_image");
    if(empty($event_image)){
        $query = "SELECT * FROM events WHERE event_id = $the_event_id";
        $keep_picture = mysqli_query($connection, $query);
        while($row = mysqli_fetch_array($keep_picture)){
            $event_image = $row['event_picture'];
        }
    }

    $query = "UPDATE events SET event_title = '{$event_title}', event_category_id = '{$event_category_id}', event_date = now(), event_organizer = '{$event_organizer}', event_status = '{$event_status}', event_tags = '{$event_tags}', event_content = '{$event_content}', event_picture = '{$event_image}', event_privacy = '{$event_privacy}', event_repeat = '{$event_repeat}', event_start_date ='{$event_start_date}',event_end_date ='{$event_end_date}', event_end_time = '{$event_end_time}', event_start_time = '{$event_start_time}', event_cost = '{$event_cost}', event_location = '{$event_location}', event_url = '{$event_url}' WHERE event_id = {$the_event_id}";

    $update_event_quary = mysqli_query($connection, $query);
    if($update_event_quary){
        echo "<p class='bg-success'>Event was succesfuly edited!</p>";
        //print_r($_POST);
    }
    else{
        die('Query failed' . mysqli_error($connection));
    }
}
?>
  
<form action="" method="post" enctype="multipart/form-data">
    <div class="form-group">
        <label for="title">Event Title</label>
        <input value="<?php echo $event_title;?>" type="text" class="form-control" name="event_title">
    </div>
     <div class="form-group">
        <label for="event_organizer">Event Organizer</label>
        <input value="<?php echo $event_organizer; ?>" type="text" class="form-control" name="event_organizer">
    </div>
     <div class="form-group">
        <label for="event_category">Event Category</label>
<!--        for="event_category"-->
        <select name="event_category" id="">
            <?php
            $query = "SELECT * FROM categories WHERE cat_id = {$event_category_id}";
            $select_event_category = mysqli_query($connection, $query);
            confirmQuery($select_event_category);
            while($row = mysqli_fetch_assoc($select_event_category)){
                $cat_id = $row['cat_id'];
                $cat_title = $row['cat_title'];
                echo "<option value=$cat_id>{$cat_title}</option>";
            }
            $query = "SELECT * FROM categories WHERE cat_id != {$event_category_id}";
            $select_categories = mysqli_query($connection, $query);
            confirmQuery($select_categories);
            while($row1 = mysqli_fetch_assoc($select_categories)){
                $cat_title = $row1['cat_title'];
                $cat_id = $row1['cat_id'];
                echo "<option value=$cat_id>{$cat_title}</option>";
            }
            ?>
        </select>
    </div>
    
    <div class="form-group">
        <label for="event_status">Event Status</label>
        <select name="event_status" id="">
           <option value="<?php echo $event_status;?>"><?php echo $event_status; ?></option>
           <?php
            if($event_status == 'draft'){
                echo "<option value='published'>published</option>";
            }elseif($event_status == 'published'){
                echo "<option value='draft'>draft</option>";
            }
            ?>
        </select>
        <label for="event_privacy">Event Publicity</label>
            <select name="event_privacy" id="">
                <option value="<?php echo $event_privacy;?>"><?php echo $event_privacy; ?></option>
                <?php
            if($event_privacy == 'public'){
                echo "<option value='private'>private</option>";
            }elseif($event_privacy == 'private'){
                echo "<option value='public'>public</option>";
            }
            ?>
        </select>
            <label for="event_repeat">Event Repeats?</label>
            <select name="event_repeat" id="">

                <?php
                $query = "SELECT event_repeat FROM events WHERE event_id = {$the_event_id}";
                $select_event_repeat = mysqli_query($connection, $query);
                confirmQuery($select_event_repeat);
                while($row = mysqli_fetch_assoc($select_event_repeat)){
                    $event_id = $row['event_id'];
                    $event_repeat = $row['event_repeat'];
                    echo "<option value=$event_id>{$event_repeat}</option>";
                }
            ?>
                <option value="no">No</option>
                <option value="weekly">Weekly</option>
                <option value="monthly">Monthly</option>
                <option value="yearly">Yearly</option>
            </select>
    </div>
     <div class="form-group">
        <label for="image">Event Image</label>
        <br>
        <img width="100" src="../images/<?php echo $event_image;?>" alt="There is no image">
        <input type="file" name="image">
    </div>
    <!--    Start date of the event-->
      <div class="row form-group">
        <div class="col-xs-2">
            <label for="start_date">Start Date</label> 
            <input type="date" class="form-control" name="start_date" id="start_date" value="<?php echo $event_start_date;?>">
        </div>
        <!--    Start time of the event-->
<?php        
$today = new DateTime();

// Make an empty array to contain the hours
$aHours = array();

// Make another DateTime object with the current date and time
$oStart = new DateTime('now');

// Set current time to midnight
$oStart->setTime(0, 0);

// Clone DateTime object (This is like 'copying' it)
$oEnd = clone $oStart;

// Add 1 day (24 hours)
$oEnd->add(new DateInterval("P1D"));

// Add each hour to an array
while ($oStart->getTimestamp() < $oEnd->getTimestamp()) {
    $aHours[] = $oStart->format('H');
    $oStart->add(new DateInterval("PT1H"));
}

// Create an array with halfs
$halfs = array(
    '0',
    '30',
);

// Get the current quarter
//$currentHalf = $today->format('i') - ($today->format('i') % 30);
$default = -1; //currenthalf is now default
?>
        <div class="col-xs-2">
            <label for="start_time">Start Time</label>
            <select class="form-control" style="line-height: 34px" name="start_time" id="start_time">
        
                <option value="<?php echo substr($event_start_time,0,5); ?>"><?php echo substr($event_start_time,0,5); ?></option>
                    <?php foreach ($aHours as $hour): ?>
                        <?php foreach ($halfs as $half): ?>
                <option value="<?php echo sprintf("%02d:%02d", $hour, $half); ?>" <?php echo ($hour == $today->format('H') && $half == $default) ? 'selected' : ''; ?>>
                <?php echo sprintf("%02d:%02d", $hour, $half); ?>
                </option>
                        <?php endforeach; ?>
                    <?php endforeach; ?>
            </select>

        </div>
        <!--    End date of the event-->
        <div class="col-xs-2"> 
            <label for="end_date">End Date</label> 
            <input type="date" class="form-control" name="end_date" id="end_date" value="<?php echo $event_end_date;?>">
        </div>
        <!--    End time of the event-->
        <div class="col-xs-2">
            <label for="end_time">End Time</label>
            <select class="form-control" name="end_time" id="end_time">             
            <option value="<?php echo substr($event_end_time,0,5); ?>"><?php echo substr($event_end_time,0,5); ?></option>
                <?php foreach ($aHours as $hour): ?>
                <?php foreach ($halfs as $half): ?>
            <option value="<?php echo sprintf("%02d:%02d", $hour, $half); ?>" <?php echo ($hour == $today->format('H') && $half == $default) ? 'selected' : ''; ?>>
                <?php echo sprintf("%02d:%02d", $hour, $half); ?>
            </option>
                <?php endforeach; ?>
                <?php endforeach; ?>

            </select>
        </div> 
        <!--   Cost of the event-->
        <div class="col-xs-3"> 
            <label for="end_date">Event Price in DKK</label> 
            <input type="text" class="form-control" name="event_cost" id="event_cost" value="<?php if($event_cost == '' || $event_cost== 0 || $event_cost== 'Free' || $event_cost== 'free'){ echo 'Free';}else{ echo $event_cost;}  ?>">
        </div>
    </div>
     <div class="form-group">
        <label for="event_tags">Event Tags</label>
        <input value="<?php echo $event_tags; ?>" type="text" class="form-control" name="event_tags">
    </div>
    <!--   Location of the event-->
     <script src="js/autocomplete_places.js"></script>
     <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyB6Y8h5biQ5Jh3FLMhzDPUEn0C8G3d6mrA&libraries=places&callback=initAutocomplete"
        async defer></script>

    <div class="form-group">
       
        <label class="control-label"for="event_location">Event Location</label>
        <input id="autocomplete" class="form-control" value="<?php echo $event_location ?>"
             onFocus="geolocate()" type="text" name="event_location">

    </div>
      <div class="form-group">
        <label for="event_url">Event Web Site</label>
        <input type="text" class="form-control" name="event_url" value="<?php echo $event_url ?>">
    </div>
     <div class="form-group">
        <label for="event_content">Event Content</label>
        <textarea name="event_content" id="" cols="30" rows="8" class="form-control"><?php echo $event_content; ?></textarea>
    </div>
    
    <div>
        <input class="btn btn-primary" type="submit" name="update_event" value="Update Event">
    </div>
</form>