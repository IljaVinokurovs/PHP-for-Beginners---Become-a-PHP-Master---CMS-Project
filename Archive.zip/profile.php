<?php
include 'includes/header.php';
include 'includes/db.php';
include 'includes/nav.php';
?>


    <!-- Page Content -->
<?php
if(isset($_SESSION['user_id'])){
    ?>
            <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            Welcome to admin panel
                            <small><?php if(isset($_SESSION['username'])){echo $_SESSION['username'];}?></small>
                        </h1>
<!--                   TABLE-->
                    <?php
                       if(isset($_SESSION['user_id'])){
                            $the_user_id = $_SESSION['user_id'];
                           
                            $query = "SELECT * FROM users WHERE user_id = $the_user_id";
                            $select_users_by_id = mysqli_query($connection, $query);
                            while($row = mysqli_fetch_assoc($select_users_by_id)){
                                $username = $row['username'];
                                $user_password = $row['user_password'];
                                $user_role = $row['user_role'];
                                $user_firstname = $row['user_firstname'];
                                $user_lastname = $row['user_lastname'];
                                $user_image = $row['user_image'];
                                $user_email = $row['user_email'];
                            }

                        if(isset($_POST['update_user'])){
                            $username = $_POST['username'];
                            $username = mysqli_real_escape_string($connection, $username);
                            $user_password = $_POST['user_password'];
                            $user_password = mysqli_real_escape_string($connection, $user_password);
                            $user_role = $_POST['user_role'];
                            $user_role = mysqli_real_escape_string($connection, $user_role);
                            $user_firstname = $_POST['user_firstname'];
                            $user_firstname = mysqli_real_escape_string($connection, $user_firstname);
                            $user_lastname = $_POST['user_lastname'];
                            $user_lastname = mysqli_real_escape_string($connection, $user_lastname);
                            $user_email = $_POST['user_email'];
                            $user_email = mysqli_real_escape_string($connection, $user_email);


                        //    $user_image = $_FILES['user_image']['name'];
                        //    $user_image_temp = $_FILES['user_image']['tmp_name'];
                        //    move_uploaded_file($user_image_temp, "../images/$user_image");
                        //    

                            $user_image = $_FILES['user_image']['name'];
                            $user_image_temp = $_FILES['user_image']['tmp_name'];
                            move_uploaded_file($user_image_temp, "../images/$user_image");
                            if(empty($user_image)){
                                $query = "SELECT * FROM users WHERE user_id = $the_user_id";
                                $keep_picture = mysqli_query($connection, $query);
                                while($row = mysqli_fetch_array($keep_picture)){
                                    $user_image = $row['user_image'];
                                }
                            }


                            $hashed_password = password_hash($user_password, PASSWORD_BCRYPT, array('cost' => 12));

                            if(empty($user_password)){ //checks if password was entered or not
                                $query = "UPDATE users SET username = '{$username}', user_role = '{$user_role}', user_firstname = '{$user_firstname}', user_lastname = '{$user_lastname}', user_image = '{$user_image}', user_email = '{$user_email}' WHERE user_id = {$the_user_id}";      
                            }else{
                                $query = "UPDATE users SET username = '{$username}', user_password = '{$hashed_password}', user_role = '{$user_role}', user_firstname = '{$user_firstname}', user_lastname = '{$user_lastname}', user_image = '{$user_image}', user_email = '{$user_email}' WHERE user_id = {$the_user_id}";
                            }



                            $update_user_quary = mysqli_query($connection, $query);
                            if($update_user_quary){
                                echo "<p class='bg-success'>Profile was succesfuly edited!</p>";
                                //print_r($_POST);
                            }
                            else{
                                die('Query failed: ' . mysqli_error($connection));
                            }
                        }
                        ?>

                        <form action="" method="post" enctype="multipart/form-data">
                            <div class="form-group">
                                <label for="username">Username</label>
                                <input value="<?php echo $username;?>" type="text" class="form-control" name="username">
                            </div>
                            <div class="form-group">
                                <label for="user_password">Password</label>
                                <input value="" placeholder="********" type="password" class="form-control" name="user_password">
                            </div>

                            <div class="form-group">
                                <label for="user_role">Role</label>
                                <select name="user_role" id="">
                                   <option value="<?php echo $user_role;?>"><?php echo $user_role; ?></option>
                                   <?php
                                    $query = "SELECT DISTINCT user_role FROM users WHERE user_role != '{$user_role}'";
                                    $select_role = mysqli_query($connection, $query);
                                    //confirmQuery($select_role);
                                    $number = 0;
                                    while($row = mysqli_fetch_array($select_role)){
                                        $u_role = $row['user_role'];
                                        echo "<option value={$u_role}>{$u_role}</option>";
                                        $number++;
                                    }
                                    ?>
                                </select>
                            </div>

                            <div class="form-group">
                                <label for="user_firstname">Firstname</label>
                                <input value="<?php echo $user_firstname; ?>" type="text" class="form-control" name="user_firstname">
                            </div>
                            <div class="form-group">
                                <label for="user_lastname">Lastname</label>
                                <input value="<?php echo $user_lastname; ?>" type="text" class="form-control" name="user_lastname">
                            </div>
                            <div class="form-group">
                                <label for="image">User Image</label>
                                <br>
                                <img width="100" src="../images/<?php echo $user_image;?>" alt="There is no image">
                                <input type="file" name="user_image">
                            </div>
                            <div class="form-group">
                                <label for="user_email">Email</label>
                                <input type="email" value="<?php echo $user_email; ?>" class="form-control" name="user_email">
                            </div>
                            <div>
                                <input class="btn btn-primary" type="submit" name="update_user" value="Update User">
                            </div>
                        </form>
                           
                    <?php       
                       }
                        ?>
                    </div>
                </div>
                <!-- /.row -->

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->
    <?php
}else{
    header("Location: ../index.php");
}
?>

<?php
include 'includes/sidebar.php';
?>
            
            

        </div>
        <!-- /.row -->

        <hr>
<?php
  include 'includes/footer.php';      
?>
